// When DOM is loaded, execute the given callback function
document.addEventListener('DOMContentLoaded', function(event){

	// Hard-coded image src urls
	var imageUrls = [
		'images/image1.jpg',
		'images/image2.jpg',
		'images/image3.jpg',
		'images/image4.jpg',
		'images/image5.jpg',
		'images/image6.jpg',
		'images/image7.jpg',
		'images/image8.jpg'
	];
	var currentImageIndex = null;	// Variable for tracking current image index
	var slideShowTimer = null;		// Variable for storing reference to interval timer

	var replaceGrid = function(size){
		// 1. Log to browser console
		console.log(size);

		// 2. Generate new grid and replace table
		var mainBody = document.getElementById('mainBody');				// Get mainBody element
		
		var existingGrid = document.getElementById('imagesGrid');		// If there is an existing imagesGrid, remove it
		
		if (existingGrid) mainBody.removeChild(existingGrid);
		
		var imagesGrid = PhotoGalleryLib.generateGrid(imageUrls, size);	//  Generate new imagesGrid
		
		mainBody.appendChild(imagesGrid);								//  then add it to mainBody

		//  Bind click handlers to the images
		PhotoGalleryLib.addImageClickHandlers(function(index){
			currentImageIndex = index;							// Update the current image index
			PhotoGalleryLib.setModalImgSrc(imageUrls[index]);	// Set the image
			PhotoGalleryLib.openPresentationModal();			// Open the modal
		});
	};

	// Close button handler
	var onClickClose = function(){
		PhotoGalleryLib.closePresentationModal();			// Close the modal
		clearInterval(slideShowTimer);						// Clear the interval timer
	};
	// Previous button handler
	var onClickPrevious = function(){
		currentImageIndex = (currentImageIndex + 7) % 8;	// Decrement current image index using modulo (for rotation)
		PhotoGalleryLib.setModalImgSrc(imageUrls[currentImageIndex]);	// Set the image
	};
	// Next button handler
	var onClickNext = function(){
		currentImageIndex = (currentImageIndex + 1) % 8;	// Increment current image index using modulo (for rotation)
		PhotoGalleryLib.setModalImgSrc(imageUrls[currentImageIndex]);	// Set the image
	};

	// Supply the function to be called when size changes
	PhotoGalleryLib.onSizeClassChange(replaceGrid);

	PhotoGalleryLib.createModal();	// Create modal and add to DOM
	PhotoGalleryLib.initModal(onClickClose, onClickPrevious, onClickNext);

	// Get the slide show button
	var slideShowBtn = document.getElementById('slideShowBtn');

	// Bind a click handler on the button
	slideShowBtn.addEventListener('click', function(evt){
		currentImageIndex = 0;											// Set the current image index to 0
		PhotoGalleryLib.setModalImgSrc(imageUrls[currentImageIndex]);	// Set the image
		PhotoGalleryLib.openPresentationModal();						// Open the modal
		slideShowTimer = setInterval(onClickNext, 1000);				// Start the interval timer
	});

});